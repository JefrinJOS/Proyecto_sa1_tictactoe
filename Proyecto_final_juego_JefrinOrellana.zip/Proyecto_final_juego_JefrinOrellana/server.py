import socket
import threading
import sys


# IP y puerto del servidor
IP = "192.168.0.110"
PORT = 55555

turn = "X"

# Socket tipo y opciones
server_socket = socket.socket(family=socket.AF_INET, type=socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

server_socket.bind((IP, PORT))
server_socket.listen()

# sockets de clientes y sus apodos
clients = {}

# depuracion
print(f"Listening for connections on {IP}:{PORT}...")


# Envio de mensajes a todos los clientes conectados
def broadcast(message, client_socket):
    # Enviar mensajes a todos los clientes excepto al remitente original
    for client in clients.keys():
        if client is not client_socket:
            client.send(message.encode("utf-8"))


# Funcion a llamar por cliente
def handle(client_socket):
    while True:
        message = client_socket.recv(1024).decode("utf-8")
        print(message)
        broadcast(message, client_socket)
        if "!exit" in message:
            client_socket.close()
            broadcast("{} left!".format(clients[client_socket]), client_socket)
            clients.pop(client_socket)
            print(clients)
            sys.exit()


# Funcion de recepcion/escucha
def receive():
    global turn
    while True:
        # Aceptar conexión
        client_socket, address = server_socket.accept()
        print("Connected with {}".format(str(address)))
        client_socket.send(turn.encode('utf-8'))
        nickname = f'player {turn}'
        if turn == "X":
            turn = "O"
        elif turn == "O":
            turn = "X"
        # # Solicitar y almacenar apodo
        # client_socket.send("/id".encode("utf-8"))
        # nickname = client_socket.recv(1024).decode("utf-8")
        # Agregar informacion del cliente
        clients.update({client_socket: nickname})
        # Comience a manejar el hilo para el cliente
        thread = threading.Thread(target=handle, args=(client_socket,))
        thread.start()


receive()
